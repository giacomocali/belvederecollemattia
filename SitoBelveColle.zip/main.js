import { Fancybox } from "@fancyapps/ui";
import "@fancyapps/ui/dist/fancybox/fancybox.css";

/*function expandImage(img) {
  console.log("expandImage(img) called");
  var modal = document.getElementById("imageModal");
  var modalImg = document.getElementById("expandedImage");
  modal.style.display = "block";
  modalImg.src = img.src;
}
function closeModal() {
  console.log("closeModal() called");
  var modal = document.getElementById("imageModal");
  modal.style.display = "none";
}*/

Fancybox.fromSelector('[data-fancybox="gallery"]');



///// CONTATTI /////

/*
function copyToClipboard(type) {
  const dummyTextarea = document.createElement("textarea");
  var textToCopy;
  if (type == "phone") {
    textToCopy = "+39 111 111 1111";
  } else if (type == "email") {
    textToCopy = "example@domain.com";
  } else if (type == "all") {
    textToCopy = "Telefono: +39 111 111 1111" + "/n Email:example@domain.com";
  }
  dummyTextarea.value = textToCopy;
  document.body.appendChild(dummyTextarea);
  dummyTextarea.select();
  document.execCommand("copy");
  document.body.removeChild(dummyTextarea);
}
*/